﻿using System;
using System.Threading;

namespace TCPServer
{
    class GameLogic
    {
        public static void Update()
        {
            ThreadManager.UpdateMain();
        }
    }
}
