﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCPServer
{
    class ServerHandle
    {
        public static void WelcomeReceived(int fromClientID, Packet packet)
        {
            int clientIdCheck = packet.ReadInt();
            string username = packet.ReadString();

            Console.WriteLine($"{Server.clients[fromClientID].tcp.socket.Client.RemoteEndPoint} connected successfully and is now player {username}.");
            
            if(fromClientID != clientIdCheck)
            {
                Console.WriteLine($"Player \"{username}\" (ID:{fromClientID}) has assumed the wrong client ID ({clientIdCheck})!");
            }
            // TODO: send palyer into game
        }

    }
}
